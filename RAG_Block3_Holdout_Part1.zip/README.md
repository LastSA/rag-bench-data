# Block 3 holdout candidate dataset

The primary set contains 10 public federal document families and 130 pages. The camera supplement contains four original physical-page photographs, one with iPhone EXIF. Run the PDFs as ten multi-page inputs using the files as shipped. Use identical files for the four configurations. Run each JPEG separately as a supplementary camera input and report results separately from the PDF holdout.

## Mapping and provenance

- manifest.json and pdf_manifest.csv record source URLs, original PDF ranges, coverage, byte hashes and page counts.
- page_map.csv maps one-based positions in packaged PDFs to one-based positions in official originals. Printed folio numbers sometimes differ. For example, Census PDF page 15 maps to dataset page 8.
- photo_manifest.csv records source and attribution, license, dimensions, and available camera metadata. Credits and other source rights notices remain applicable. The provided photographs are the original acquired bytes.
- The PDFs are page selections, with the source text layer retained. All selected pages were checked for equivalent extracted text and low-resolution rendered pixels with annotations disabled. Sample visuals were inspected. The excerpts retain contiguous page context within each selection. Their hashes differ from the source documents.
- Before scoring, Claude should cross-check these families and source IDs against all previous private manifests. The local hash comparison covers only the manifests available in the audit workspace. Here, held out means held out from this benchmark's development and prior evaluation.

## Priority reference locations

Use the original PDF page IDs below and translate them through page_map.csv. These are review targets, with answer keys still to be drafted and checked independently from source visuals.

| Source | Original PDF pages | Checks |
|---|---|---|
| Civil Rights Act | 1–12 | Scan transcription, headings, marginal notes and line order |
| NASA 1981 report | 5–12 | Scan transcription and native legacy OCR layer, captions and reading order |
| IRS Publication 1040 | 2–12 | Adjacent continued pages, same income band and correct filing-status column, repeated side-by-side table headers |
| BLS productivity | 1–3, 9–15 | Chart trends, labeled series, quarterly rates and dense data tables |
| Census income | 8–9, 15–16, 21–24 | Chart conclusions, two figure owners on page 15, continued Table A-2 |
| Federal Reserve SHED | 12–15, 16, 17–23 | Chart comparisons, blank-page behavior and table cells |
| CSB Dow Plaquemine | 13, 15–16 | Agency-authored diagrams, directed links and printed captions |
| NTSB East Palestine | 64, 75–76 | Competing figure captions, figure retrieval and a nearby table |
| CFR walking-working surfaces | 2–16 | Two-column order and nested numbered provisions |
| GAO federal AML report | 12, 15–16 | Labeled process steps, directed links and figure provenance |

Treat the embedded OCR in scans as a diagnostic channel and verify gold text against source imagery. Draft chart takeaways and caption owners before reviewing outputs. Use all already-reviewed checks on their existing blocks. Keep these files out of tuning. Freeze the manifest after inventory reconciliation and reference review.

## Phone capture extension

The camera supplement is small and has only one confirmed smartphone capture. For a matched ten-photo extension, print the benchmark pages in phone_capture_targets.csv and photograph each separately with a phone. Pair each image to its source family and original PDF page. Leave the page borders visible and vary perspective, lighting and curvature. Record capture condition without counting these as independent document families. Accept only source-readable spans as reference text. The list provides targets for physical capture.
